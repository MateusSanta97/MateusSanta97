export interface PersonData {
    firstName: string,
    lastName: string,
    email: string
}